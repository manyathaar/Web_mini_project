
const mongoose = require("mongoose");

const genreSchema = mongoose.Schema({
  //Mongoose schema defines the structure of the document in key-property pairs
  _id: mongoose.Schema.Types.ObjectId,//property-_id,schema - objectId
  genre: { type: String, required: true },
});

//When you call mongoose.model() on a schema, Mongoose compiles a model for you

const Genre = mongoose.model("Genre", genreSchema, "genres");

module.exports = Genre;

//Genre - model name
//genreSchema - schema
//genres - collection