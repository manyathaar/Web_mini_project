/*jwt- defines a compact and self-contained way of 
securely transmitting information between parties as a JSON object.
JWT is very popular for handling authentication and authorization via HTTP.
*/

/*
We are now going to create the middleware which will protect selected routes, 
and ensure that a user is authenticated before allowing their requests to go through.
*/
const jwt = require("jsonwebtoken");

module.exports = (req, res, next) => {
  try {
    const token = req.headers.authorization.split(" ")[1];
    const decoded = jwt.verify(token, process.env.JWT_KEY);
    req.userData = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ message: "Authentication has failed!" });
  }
};

/*we extract the token from the incoming request's  Authorization.
we use the split function to get everything after the space in the header
and any errors thrown here will wind up in the  catch  block.
we then use the  verify  function to decode our token,
if the token is not valid, this will throw an error.
otherwise, our user is authenticated and
 we pass execution along using then next() function
*/