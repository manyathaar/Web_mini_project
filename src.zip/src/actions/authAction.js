import {
  LOGIN_SUCCESS,
  LOGIN_ERROR,
  SIGNOUT,
  SIGNUP_SUCCESS,
  SIGNUP_ERROR,
} from "./actionTypes";
import Axios from "axios";//Axios-Promise based HTTP client for the browser and node.js

export const signIn = (credentials) => {
  //Submits a block for asynchronous execution  
  return async (dispatch) => {
    try {
      //make a POST request with Axios
      const result = await Axios.post("/api/users/login", credentials);
     //await - to pause the function execution and resume after the data comes in
      dispatch({ type: LOGIN_SUCCESS, payload: result });//payload- gives response
    } catch (error) {
      dispatch({ type: LOGIN_ERROR, error });
    }
  };
};
//dispatch()-Dispatches an action in order to to trigger a state change
export const signUp = (credentials) => {
  return async (dispatch) => {
    try {
      const result = await Axios.post("/api/users/signup", credentials);
      dispatch({ type: SIGNUP_SUCCESS, payload: result });
    } catch (error) {
      dispatch({ type: SIGNUP_ERROR, error });
    }
  };
};

export const signOut = () => {
  return (dispatch) => {
    dispatch({ type: SIGNOUT });
  };
};

//Redux is a predictable state container for JavaScript apps
//It lets your React components read data from a Redux store, 
//and dispatch actions to the store to update data.