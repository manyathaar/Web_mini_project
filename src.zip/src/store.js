/*The reducer is a pure function that takes the previous state and an action,
 and returns the next state*/

import rootReducer from "./reducers/rootReducer";
import thunk from "redux-thunk";//Thunk is a middleware for Redux.
import { createStore, applyMiddleware, compose } from "redux";

const middleWare = [thunk];
const initialState = {};

const store = createStore( //createStore()-Creates a Redux store that holds the complete state tree of your app.
  rootReducer,
  initialState,
  compose(applyMiddleware(...middleWare))
);

export default store;

//The thunk can be used to delay the dispatch of an action, or to dispatch only if a certain condition is met.
//createStore-Creates a Redux store that holds the state tree. The only way to change the data in the store is to call dispatch() on it.
//applyMiddleware- Creates a store enhancer that applies middleware to the dispatch method of the Redux store. This is handy for a variety of tasks, such as expressing asynchronous actions in a concise manner, or logging every action payload.
//compose - used to pass multiple store enhancers to the store.
