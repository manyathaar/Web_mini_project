import Joi from "@hapi/joi";

export const movieSchema = {
  id: Joi.string(), //string type
  //Joi.string().required()- whether a property is required with the help of the method required
  title: Joi.string().required().label("Title"),
  genre: Joi.string().required().label("Genre"),
  numberInStock: Joi.number().min(0).required().label("Number In Stocks"),
  description: Joi.string().required().label("Description"),
  image: Joi.object().allow(null).label("Cover Image"),
};

/*Joi.number() and also supporting helper operations such as min() and max(),
 like so Joi.number().min(1).max(10)
*/
//Joi.object().allow(null)-to allow the object to be null