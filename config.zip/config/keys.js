if (process.env.NODE_ENV === 'development') module.exports = require('./keys_prod');
else module.exports = require('./keys_dev');

//process.env.NODE_ENV is set to 'development' or 'production'


//keys.js checks the Node.js execution environement 
//i.e. NODE_ENV and exports the correct keys file.
