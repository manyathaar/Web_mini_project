//keys_prod.js is used for production environment

module.exports = { 
  mongoURI: process.env.MONGODB_URI, //Connection String of mongoDB
  secretOrKey: process.env.SECRET_OR_KEY //Secret Key
}
//process.env-returns object containing the user environment
/* mongoURI- can be used to create a Mongo instance and 
    it describes the hosts to be used and options.*/
// secretOrKey-supplying a symmetric secret for signing the token