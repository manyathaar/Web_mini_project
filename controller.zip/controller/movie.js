const mongoose = require("mongoose");
const Movie = require("../models/movie");
const multer = require("multer");
const fs = require("fs");

exports.getAllMovies = (req, res) => {
  Movie.find()
    .then((movies) =>
      res.status(200).json({
        count: movies.length,
        movies: movies,
      })
    )
    .catch((err) => res.status(500).json({ error: err }));
};
//disk storage engine gives you full control of storing files to disk
const storage = multer.diskStorage({ 
  destination: (req, file, callback) => { // determines destination path for uploaded files
    callback(null, "./uploads/");
  },
  filename: (req, file, callback) => { //name of the uploaded file
    callback(null, Date.now() + "-" + file.originalname);
  },
});

const upload = multer({ storage: storage }).single("image");
// storage - processes files uploaded via multer
//single- processes a single file associated with the given form field
exports.addMovie = (req, res) => {
  upload(req, res, (err) => {
    if (err) res.status(500).json(err);
    else {
      fs.readFile(req.file.path, function (err, data) {
        if (err) throw err;
        else {
          const contentType = req.file.mimetype;//all of the file info is accessed 
          const newMovie = new Movie({
            _id: mongoose.Types.ObjectId(),//configuration for a path in a schema
            
            //req.body holds parameters that are sent from the client as part of POST request
            title: req.body.title,
            numberInStock: req.body.numberInStock,
            genre: req.body.genre,
            image: { data, contentType },
            rate: 0,
          });

          //Saving new movie in db
          newMovie.save((err, movie) => {
            if (err) res.status(500).json({ error: err });
            else {
              res.status(201).json({
                message: "A new movie added",
                movie: movie,
              });
            }
          });
        }
      });
    }
  });
};

